#pragma once

#include <iostream>
#include <sstream>
#include <vector>

#include <Windows.h>
#include <TlHelp32.h>
